import org.junit.jupiter.api.Test;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

public class SILab2Test {
    private List<User> createList(String... elems) {
        List<User> userList = new ArrayList<>();

        for (String elem : elems) {
            String[] userDetails = elem.split(","); // Split the string by commas to extract the individual values
            if (userDetails.length == 3) {
                String param1 = userDetails[0].trim();
                String param2 = userDetails[1].trim();
                String param3 = userDetails[2].trim();
                User user = new User(param1, param2, param3); // Assuming User class has a constructor that takes three string parameters
                userList.add(user);
            }
        }

        return userList;
    }





    @Test
    void MultipleConditions(){

        List<User> allUsers= createList();

        User test1=new User("someusername", null, "email@gmail.com" );
        User test2=new User("someusername", "password", null );
        User test3=new User("someusername", null, null );
        User test4=new User(null,null,null);

        RuntimeException runtimeException= new RuntimeException();

        runtimeException = assertThrows(RuntimeException.class, () -> SILab2.function(null, allUsers));
        assertFalse(runtimeException.getMessage().contains("User not correct defined"));

        runtimeException = assertThrows(RuntimeException.class, () -> SILab2.function(test1, allUsers));
        assertFalse(runtimeException.getMessage().contains("User not correct defined"));

        runtimeException = assertThrows(RuntimeException.class, () -> SILab2.function(test2, allUsers));
        assertFalse(runtimeException.getMessage().contains("User not correct defined"));

        runtimeException = assertThrows(RuntimeException.class, () -> SILab2.function(test3, allUsers));
        assertFalse(runtimeException.getMessage().contains("User not correct defined"));

        runtimeException = assertThrows(RuntimeException.class, () -> SILab2.function(test4, allUsers));
        assertFalse(runtimeException.getMessage().contains("User not correct defined"));

    }
}
